#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
#include <ros.h>

geometry_msgs::Pose forward_kinematics(float speedR, float speedL, float yaw)
{
    geometry_msgs::Pose output;



    return output;
}

void inverse_kinematics(geometry_msgs::Twist msg, float &speedR, float &speedL)
{
    float x = msg.linear.x;
    float yaw = msg.angular.z;

    

    // Calculate speedR and speedL
    // ...
}